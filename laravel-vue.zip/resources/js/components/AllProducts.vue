<template>

    <AllProductsPaginator></AllProductsPaginator>
  </template>

  <script>
//   import * as Pagination from 'vue-pagination-2';
import AllProductsPaginator from './AllProductsPaginator.vue'
  export default {
    components: { AllProductsPaginator },
    data() {
      return {

      };
    },
    mounted() {

    },


  };
  </script>

  <style scoped>

  </style>
