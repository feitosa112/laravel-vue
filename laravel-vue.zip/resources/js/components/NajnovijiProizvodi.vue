<template>
    <div class="col-2 col-sm-12 col-lg-2 col-md-12 d-none d-lg-block">
                <small>Najnoviji proizvodi</small>
                <div class="row mb-2">
                    <div class="col-3">
                        <img src="../../images/butik1.jpeg" style="height: 40px;" alt="">
                    </div>
                    <div class="col-8">
                        <small class="float-start" style="margin-left: 8px;">Ime</small>
                        <a href="" class="badge badge-success bg-sm float-end">55km</a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-3">
                        <img src="../../images/butik1.jpeg" style="height: 40px;" alt="">
                    </div>
                    <div class="col-8">
                        <small class="float-start" style="margin-left: 8px;">Ime</small>
                        <a href="" class="badge badge-success bg-sm float-end">55km</a>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-3">
                        <img src="../../images/butik1.jpeg" style="height: 40px;" alt="">
                    </div>
                    <div class="col-8">
                        <small class="float-start" style="margin-left: 8px;">Ime</small>
                        <a href="" class="badge badge-success bg-sm float-end">55km</a>
                    </div>
                </div>


            </div>
</template>

<script>
export default {

}
</script>
