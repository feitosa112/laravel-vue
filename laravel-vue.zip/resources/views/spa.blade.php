@extends('layouts.app')
@section('title')
    ButikTrend

    @endsection
@section('content')



<div id="app">

</div>
@endsection
