<?php $__env->startSection('title'); ?>
    ButikTrend

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<script>
    window.user = <?php echo json_encode($user ?? null, 15, 512) ?>;
</script>
<div id="app">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\VLAR\laravel-vue\resources\views\home.blade.php ENDPATH**/ ?>