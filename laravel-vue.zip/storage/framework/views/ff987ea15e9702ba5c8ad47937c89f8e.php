</html>
<?php /**PATH C:\Users\Administrator\Desktop\VLAR\laravel-vue\resources\views/partials/footer.blade.php ENDPATH**/ ?>