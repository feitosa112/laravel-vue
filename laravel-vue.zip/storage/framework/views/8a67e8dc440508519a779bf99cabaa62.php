<?php $__env->startSection('title'); ?>
    ButikTrend

    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div id="app">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\VLAR\laravel-vue\resources\views\spa.blade.php ENDPATH**/ ?>